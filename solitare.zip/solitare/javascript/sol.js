// All of the parts of solitare
var deck = [];
var hand = [];
var game = [];
var cnt = 0;


// Dummy variables for use
var i = 0;
var j = 0;
var k = 0;
var len = 0;
var temp [];
var grw = 0;
var gcm = 0;
var sel = false;
var cng = false;

// This creates an array of every card in a standard deck and fills it for reference
cards = [];
for(i = 0; i < 13; i++) {
    for(j = 0; j < 4; j++) {
        k = i * 4;
        k += j;
        cards[k] = {};
        cards[k][val] = i + 1;
        cards[k][slk] = false;
        cards[k][see] = false;
        if( j == 0) {
            cards[k][clr] = "black";
            cards[k][sut] = "spades";
        }
        else if(j == 1) {
            cards[k][clr] = "red";
            cards[k][sut] = "diamonds";
        }
        else if(j == 2) {
            cards[k][clr] = "black";
            cards[k][sut] = "clubs";
        }
        else {
            cards[k][clr] = "red";
            cards[k][sut] = "hearts";
        }
    }

}

// Shuffles the cards
function shuffle(ary) {
    ary.sort(function(a, b){return 0.5 - Math.random()});
    return ary;
}

function pic(brw, bcm) {
    
}

// Starts a new game
function start() {
    //Wipes everything
    var deck = [];
    var hand = [];
    var game = [];
    var cnt = 0;
    
    // Initiates a shuffle
    deck = shuffle(cards);
    
    // Deals out the cards
    for(i = 0; i < 7; i++) {
        game[i] = [];
        for( j = i; j < 7; j++) {
            game[i][j] = deck.pop();
            if(i == j) {
                game[i][j][see] = true;
            }
        }
    }
    game[7] = [];
    game[8] = [];
    game[9] = [];
    game[10] = [];
    game[11] = [];
}

function draw() {
    while(game[11].length > 0) {
        temp.push(game[11].pop());
    }
    while(temp.length > 0) {
        hand.push(temp.pop());
    }
    
    if(deck.length() <= 0) {
        deck = hand;
        hand = [];
        for(i = 0; i < deck.length; i++) {
            deck[i][see] = false;
        }
    }
    else {
        j = 0;
        while(deck.length > 0) {
            game[11].push(deck.pop());
            game[11][j][see] = true;
            j += 1;
        }
    }
}

function move(brw, bcm) {
    if(game[brw][bcm][see]) {
        if(sel) {
            if(bcm + 1 == game[brw].length){
                if(brw > 6 && brw < 11) {
                    if(game[brw][bcm][sut] == game[grw][gcm][sut] && gcm + 1 == game[grw].length && game[grw][gcm][val] == game[brw][bcm][val] + 1) {
                        game[grw][gcm][slk] = false;
                        game[brw].push(game[grw].pop());
                        sel = false;
                        grw = 0;
                        gcm = 0;
                        cng = true;
                    }
                    else if(game[brw][bcm][val] == 0 && game[grw][gcm][val] == 1) {
                        game[brw].pop();,     
                    }
                }
                else if(game[brw][bcm][clr] != game[grw][gcm][clr] && game[brw][bcm][val] == game[grw][gcm][val] + 1) {
                    if(grw < 7) {
                        if(game[brw][bcm][val] > 13) {
                            game[brw].pop();
                        }
                        
                        for(i = game[grw].length; i > gcm; i--) {
                            temp.push(game[grw].pop());
                        }
                        while(temp.length > 0) {
                            game[brw].push(temp.pop());
                        }
                        cng = true;
                        
                        if(game[grw].length == 0) {
                            game[grw][0] = {};
                            game[grw][0][val] = 14;
                            game[grw][0][clr] = "none";
                            game[grw][0][sut] = "none";
                            game[grw][0][slk] = false;
                            game[grw][0][see] = true;
                            
                        }
                    }
                    else {
                        if(game[brw][bcm][val] > 13) {
                            game[brw].pop();
                        }
                        
                        game[brw].push(game[grw].pop());
                        cng = true;
                        
                        if(game[11].length == 0 && hand.length != 0) {
                            game[11].push(hand.pop());
                        }
                    }
                }
            }
            
            
            if((brw == grw && bcm == gcm) || cng) {
                sel = false;
                grw = 0;
                gcm = 0;
                game[brw][bcm][slk] = false;
                cng = false;
            }
        }
        else if(brw < 11 || bcm + 1 == game[brw].length){
            sel = true;
            grw = brw;
            gcm = bcm;
            game[brw][bcm][slk] = true;
        }
    }
}